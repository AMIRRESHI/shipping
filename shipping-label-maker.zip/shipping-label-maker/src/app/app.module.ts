import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
//import { ShippingLabelMarkerComponent } from './features/shipping-label-maker/shipping-label-marker.component';
import { SharedModule } from './shared/shared.module';
import { ShippingLabelMakerComponent } from './features/shipping-label-maker/shipping-label-maker/shipping-label-maker.component';
import { SenderAddressStepComponent } from './features/shipping-label-maker/sender-address-step/sender-address-step.component';
import { RecieverAddressStepComponent } from './features/shipping-label-maker/reciever-address-step/reciever-address-step.component';
import { WeightStepComponent } from './features/shipping-label-maker/weight-step/weight-step.component';
import { ShippingOptionStepComponent } from './features/shipping-label-maker/shipping-option-step/shipping-option-step.component';
import { ConfirmStepComponent } from './features/shipping-label-maker/confirm-step/confirm-step.component';
import { ShippingLabelComponent } from './features/shipping-label-maker/shipping-label/shipping-label.component';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent,
    ShippingLabelMakerComponent,
    SenderAddressStepComponent,
    RecieverAddressStepComponent,
    WeightStepComponent,
    ShippingOptionStepComponent,
    ConfirmStepComponent,
    ShippingLabelComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    SharedModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
