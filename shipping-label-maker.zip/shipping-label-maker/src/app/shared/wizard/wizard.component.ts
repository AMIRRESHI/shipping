import { Component, ViewChild, OnInit, Input, Output, EventEmitter, ContentChildren, QueryList, AfterViewInit } from '@angular/core';
import { WizardStepComponent } from '../wizard-step/wizard-step.component';
import { WizardAction } from '../models/wizard-action';
import { WizardData } from '../models/wizard-data';
import { ShippingLabelMakerComponent } from '../../features/shipping-label-maker/shipping-label-maker/shipping-label-maker.component';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.css']
})
export class WizardComponent implements OnInit {
  @ContentChildren(WizardStepComponent)
  public steps: QueryList<WizardStepComponent>;

  @Input() wizardContext: object;
  @Output() complete: EventEmitter<object>= new EventEmitter();

  private wizardData: WizardData;

  private currentStepNo = 0;
  private currentStep: WizardStepComponent;

  constructor() { }

  ngOnInit() {
    
    this.wizardData = {
      context: this.wizardContext,
      onAction: (action: string) => {
        // var wizardAction:WizardAction = WizardAction[action];

        switch (action) {
          case "Next":
            this.onNext();
            break;
          case "Prev":
            this.onPrev();
            break;
          //case "End":
            
        }
      }
    }
  }

  onPrev() {
    if (this.currentStepNo > 0) {
      this.currentStepNo--;
    }
  }

  onNext() {
    if (this.currentStepNo < this.steps.length - 1) {
      this.currentStepNo++;
    }else{
      this.complete.emit(this.wizardContext);
    }
  }

  getStep() {
    var step = this.steps.toArray()[this.currentStepNo];
    step.wizardData = this.wizardData;
    return step;
  }

  getPercentage() {
    return 100 / this.steps.length * (this.currentStepNo + 1);
  }

  

}
