import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { WizardData } from '../models/wizard-data';
import { WizardAction } from '../models/wizard-action';


@Component({
  selector: 'app-wizard-step',
  templateUrl: './wizard-step.component.html',
  styleUrls: ['./wizard-step.component.css']
})
export class WizardStepComponent implements OnInit {

  @ViewChild('innerTemplate')
  public innerTemplate: TemplateRef<any>;
  public wizardData: WizardData

  constructor() { }

  ngOnInit() {

  }

  onNext() {
    this.wizardData.onAction("Next");
  }

  onPrev() {
    this.wizardData.onAction("Prev");
  }
}
