export interface IShippingInfo {
    from: IFrom,
    to: ITo,
    weight: number,
    shippingOption: number
  }

  export interface IFrom {
    name: string,
    street: string,
    city: string,
    state: string,
    zip: string
  }
  export interface ITo {
    name: string,
    street: string,
    city: string,
    state: string,
    zip: string
  }