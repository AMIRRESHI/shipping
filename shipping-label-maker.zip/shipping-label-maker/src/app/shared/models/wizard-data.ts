export interface WizardData {
    context: object;
    onAction: (action: string) => void;
};