export enum ShippingOption {
    Ground = 1,
    Priority = 2
};