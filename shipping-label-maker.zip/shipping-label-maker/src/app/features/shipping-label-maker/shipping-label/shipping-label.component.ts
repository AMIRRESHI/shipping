import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipping-label',
  templateUrl: './shipping-label.component.html',
  styleUrls: ['./shipping-label.component.css']
})
export class ShippingLabelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
