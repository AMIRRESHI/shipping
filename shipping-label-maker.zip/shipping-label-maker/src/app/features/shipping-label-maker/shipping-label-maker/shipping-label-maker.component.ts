import { Component, OnInit, ViewChild, ViewContainerRef, TemplateRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { IShippingInfo } from '../../../shared/models/interfaces';
import { ShippingOption } from '../../../shared/models/shipping-option';

@Component({
  selector: 'app-shipping-label-maker',
  templateUrl: './shipping-label-maker.component.html',
  styleUrls: ['./shipping-label-maker.component.css']
})
export class ShippingLabelMakerComponent {

  shippingInfo: IShippingInfo =
    {
      from: {
        name: undefined,
        street: undefined,
        city: undefined,
        state: undefined,
        zip: undefined
      },
      to: {
        name: undefined,
        street: undefined,
        city: undefined,
        state: undefined,
        zip: undefined
      },
      weight: undefined,
      shippingOption: undefined
    }

  @ViewChild('senderForm') senderForm: NgForm;
  @ViewChild('receiverForm') receiverForm: NgForm;
  @ViewChild('weightForm') weightForm: NgForm;
  @ViewChild('shippingOptionForm') shippingOptionForm: NgForm;

  @ViewChild("vc", { read: ViewContainerRef }) vc: ViewContainerRef;
  @ViewChild("tpl") tpl: TemplateRef<any>;

  constructor() {

  }

  onComplete(data) {
    this.shippingInfo.from = this.senderForm.form.value;
    this.shippingInfo.to = this.receiverForm.form.value;

    var finalShippingObj: IShippingInfo = {
      from: this.senderForm.form.value,
      to: this.receiverForm.form.value,
      weight: this.shippingInfo.weight,
      shippingOption: this.shippingInfo.shippingOption
    }
    alert("plz check browser console");
    console.log(finalShippingObj);
  }

  getWeight() {
    return this.shippingInfo.weight;
  }
  getShippingOption() {
    return this.shippingInfo.shippingOption;
  }

  getShippingCost() {
    const shippingRate = 0.40;
    var shippingOption = this.getShippingOption();
    var shippingWeight = this.getWeight();
    var shippingCost;
    this.vc.clear();
    if (shippingWeight && shippingOption){
      shippingCost = shippingWeight * shippingRate * (shippingOption === ShippingOption.Ground ? 1 : 1.5);
    }else {
      let view = this.tpl.createEmbeddedView(null);
      this.vc.insert(view);
    }

    return shippingCost;
  }



}
