import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipping-option-step',
  templateUrl: './shipping-option-step.component.html',
  styleUrls: ['./shipping-option-step.component.css']
})
export class ShippingOptionStepComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
