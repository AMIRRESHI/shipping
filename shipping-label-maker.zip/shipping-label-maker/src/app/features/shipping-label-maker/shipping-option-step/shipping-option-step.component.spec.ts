import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShippingOptionStepComponent } from './shipping-option-step.component';

describe('ShippingOptionStepComponent', () => {
  let component: ShippingOptionStepComponent;
  let fixture: ComponentFixture<ShippingOptionStepComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShippingOptionStepComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShippingOptionStepComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
