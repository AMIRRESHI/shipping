import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-step',
  templateUrl: './confirm-step.component.html',
  styleUrls: ['./confirm-step.component.css']
})
export class ConfirmStepComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
