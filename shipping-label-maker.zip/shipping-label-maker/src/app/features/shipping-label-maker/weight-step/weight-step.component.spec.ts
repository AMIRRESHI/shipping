import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeightStepComponent } from './weight-step.component';

describe('WeightStepComponent', () => {
  let component: WeightStepComponent;
  let fixture: ComponentFixture<WeightStepComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeightStepComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeightStepComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
