import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weight-step',
  templateUrl: './weight-step.component.html',
  styleUrls: ['./weight-step.component.css']
})
export class WeightStepComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
