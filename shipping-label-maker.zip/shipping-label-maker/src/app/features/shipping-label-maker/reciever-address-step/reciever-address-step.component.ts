import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reciever-address-step',
  templateUrl: './reciever-address-step.component.html',
  styleUrls: ['./reciever-address-step.component.css']
})
export class RecieverAddressStepComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
