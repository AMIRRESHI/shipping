import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecieverAddressStepComponent } from './reciever-address-step.component';

describe('RecieverAddressStepComponent', () => {
  let component: RecieverAddressStepComponent;
  let fixture: ComponentFixture<RecieverAddressStepComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecieverAddressStepComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecieverAddressStepComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
