import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sender-address-step',
  templateUrl: './sender-address-step.component.html',
  styleUrls: ['./sender-address-step.component.css']
})
export class SenderAddressStepComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
