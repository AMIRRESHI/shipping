import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SenderAddressStepComponent } from './sender-address-step.component';

describe('SenderAddressStepComponent', () => {
  let component: SenderAddressStepComponent;
  let fixture: ComponentFixture<SenderAddressStepComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SenderAddressStepComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SenderAddressStepComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
